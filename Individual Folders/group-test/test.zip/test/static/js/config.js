// API key
const API_KEY = "pk.eyJ1IjoicGhlbm5lc3NleSIsImEiOiJjazJwaTY5dWUwNG1tM2JwZ3c5MnhlMjduIn0.frDEbWukCkCtTtxifEw7Xg";